import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { Home, ArrowDownCircle, TrendingUp, ArrowUpCircle, Clock, User as UserIcon } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const navItems = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/deposit', label: 'Deposit', icon: ArrowDownCircle },
  { to: '/invest', label: 'Invest', icon: TrendingUp },
  { to: '/withdraw', label: 'Withdraw', icon: ArrowUpCircle },
  { to: '/history', label: 'History', icon: Clock },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

export default function Layout() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto relative">
      <header className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-5 py-4 sticky top-0 z-30 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-6 h-6" />
            <span className="font-bold text-lg">Kagoda Invest</span>
          </div>
          {profile && (
            <button
              onClick={async () => {
                await signOut();
                navigate('/login');
              }}
              className="text-sm text-emerald-100 hover:text-white transition-colors"
            >
              Sign Out
            </button>
          )}
        </div>
      </header>

      <main className="flex-1 pb-24">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-30">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-colors ${
                    isActive ? 'text-emerald-600' : 'text-gray-400 hover:text-gray-600'
                  }`
                }
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </NavLink>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
