import { useState } from 'react';

interface PinInputProps {
  value: string;
  onChange: (value: string) => void;
  length?: number;
}

export default function PinInput({ value, onChange, length = 4 }: PinInputProps) {
  const [focused, setFocused] = useState(false);

  const digits = Array.from({ length }, (_, i) => value[i] || '');

  return (
    <div className="flex justify-center gap-3">
      {digits.map((d, i) => (
        <div
          key={i}
          className={`h-14 w-12 rounded-xl border-2 flex items-center justify-center text-2xl font-bold transition-all ${
            d
              ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
              : focused
                ? 'border-emerald-400 bg-white'
                : 'border-gray-200 bg-gray-50'
          }`}
        >
          {d ? '•' : ''}
        </div>
      ))}
      <input
        type="tel"
        inputMode="numeric"
        pattern="[0-9]*"
        maxLength={length}
        value={value}
        onChange={(e) => {
          const v = e.target.value.replace(/\D/g, '').slice(0, length);
          onChange(v);
        }}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        className="absolute opacity-0 w-[1px] h-[1px]"
        aria-label="PIN input"
      />
    </div>
  );
}
