export const DEPOSIT_NUMBERS = {
  MTN: '+256793298877',
  Airtel: '0749392009',
};

export const MIN_WITHDRAWAL = 5000;

export const CURRENCY = 'UGX';

export function formatUGX(amount: number): string {
  return new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: 'UGX',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
