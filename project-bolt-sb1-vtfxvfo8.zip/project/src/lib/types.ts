export interface Profile {
  id: string;
  full_name: string;
  phone: string;
  pin: string;
  balance: number;
  profit_balance: number;
  total_deposited: number;
  total_withdrawn: number;
  created_at: string;
}

export interface InvestmentPackage {
  id: string;
  name: string;
  min_amount: number;
  max_amount: number;
  daily_rate: number;
  duration_days: number;
  is_active: boolean;
  sort_order: number;
}

export interface Investment {
  id: string;
  user_id: string;
  package_id: string;
  amount: number;
  daily_profit: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'completed' | 'cancelled';
  last_credited_at: string;
  created_at: string;
  package?: InvestmentPackage;
}

export interface Transaction {
  id: string;
  user_id: string;
  type: 'deposit' | 'withdrawal' | 'investment' | 'profit';
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  provider: string | null;
  phone: string | null;
  description: string | null;
  reference: string | null;
  created_at: string;
}
