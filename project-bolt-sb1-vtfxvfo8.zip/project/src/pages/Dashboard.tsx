import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, ArrowDownCircle, ArrowUpCircle, Wallet, Award, Clock } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatUGX, formatDate } from '@/lib/constants';
import type { Investment } from '@/lib/types';

export default function Dashboard() {
  const { profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [totalProfitEarned, setTotalProfitEarned] = useState(0);

  useEffect(() => {
    if (!profile) return;

    (async () => {
      await supabase.rpc('credit_daily_profits');
      await refreshProfile();

      const { data: invData } = await supabase
        .from('investments')
        .select('*, package:investment_packages(*)')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false });

      if (invData) setInvestments(invData as Investment[]);

      const { data: profitTx } = await supabase
        .from('transactions')
        .select('amount')
        .eq('user_id', profile.id)
        .eq('type', 'profit')
        .eq('status', 'completed');

      if (profitTx) setTotalProfitEarned(profitTx.reduce((sum, t) => sum + Number(t.amount), 0));
    })();
  }, [profile?.id]);

  if (!profile) return null;

  const activeInvestments = investments.filter((i) => i.status === 'active');

  return (
    <div className="p-5 space-y-5">
      {/* Balance Card */}
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-2 text-emerald-100 text-sm mb-1">
          <Wallet className="w-4 h-4" />
          Total Balance
        </div>
        <div className="text-4xl font-bold mb-4">{formatUGX(profile.balance + profile.profit_balance)}</div>
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/20">
          <div>
            <p className="text-emerald-100 text-xs">Investment Balance</p>
            <p className="text-lg font-semibold">{formatUGX(profile.balance)}</p>
          </div>
          <div>
            <p className="text-emerald-100 text-xs">Profit Balance</p>
            <p className="text-lg font-semibold">{formatUGX(profile.profit_balance)}</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => navigate('/deposit')}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col items-center gap-2 hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center">
            <ArrowDownCircle className="w-6 h-6 text-emerald-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">Deposit</span>
        </button>
        <button
          onClick={() => navigate('/invest')}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col items-center gap-2 hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-blue-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">Invest</span>
        </button>
        <button
          onClick={() => navigate('/withdraw')}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col items-center gap-2 hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center">
            <ArrowUpCircle className="w-6 h-6 text-amber-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">Withdraw</span>
        </button>
        <button
          onClick={() => navigate('/history')}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col items-center gap-2 hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center">
            <Clock className="w-6 h-6 text-gray-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">History</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-500 text-xs mb-1">
            <Award className="w-3.5 h-3.5" />
            Total Profit Earned
          </div>
          <p className="text-lg font-bold text-emerald-600">{formatUGX(totalProfitEarned)}</p>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-500 text-xs mb-1">
            <TrendingUp className="w-3.5 h-3.5" />
            Active Investments
          </div>
          <p className="text-lg font-bold text-blue-600">{activeInvestments.length}</p>
        </div>
      </div>

      {/* Active Investments */}
      <div>
        <h2 className="text-sm font-semibold text-gray-700 mb-3">Active Investments</h2>
        {activeInvestments.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-gray-100">
            <TrendingUp className="w-10 h-10 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-400 text-sm">No active investments yet</p>
            <button
              onClick={() => navigate('/invest')}
              className="mt-3 text-emerald-600 text-sm font-medium hover:text-emerald-700"
            >
              Start investing →
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {activeInvestments.map((inv) => {
              const totalReturn = inv.daily_profit * (inv.package?.duration_days ?? 0);
              const endDate = new Date(inv.end_date);
              const now = new Date();
              const totalDuration = inv.package?.duration_days ?? 1;
              const elapsed = Math.min(
                Math.floor((now.getTime() - new Date(inv.start_date).getTime()) / (1000 * 60 * 60 * 24)),
                totalDuration
              );
              const progress = Math.round((elapsed / totalDuration) * 100);

              return (
                <div key={inv.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-4 h-4 text-emerald-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-sm text-gray-800">{inv.package?.name}</p>
                        <p className="text-xs text-gray-400">{formatUGX(inv.amount)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-400">Daily Profit</p>
                      <p className="text-sm font-semibold text-emerald-600">{formatUGX(inv.daily_profit)}</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Progress: {progress}%</span>
                      <span>Ends: {formatDate(inv.end_date)}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-full transition-all"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-gray-400 mt-2">
                      <span>Expected return: {formatUGX(totalReturn)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
