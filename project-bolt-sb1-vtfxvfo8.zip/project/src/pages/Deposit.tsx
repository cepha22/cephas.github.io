import { useState } from 'react';
import { ArrowDownCircle, Smartphone, CheckCircle, AlertCircle, Lock } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { DEPOSIT_NUMBERS, formatUGX } from '@/lib/constants';
import PinInput from '@/components/PinInput';

type Step = 'details' | 'pin' | 'success';

export default function Deposit() {
  const { profile, refreshProfile } = useAuth();
  const [step, setStep] = useState<Step>('details');
  const [provider, setProvider] = useState<'MTN' | 'Airtel'>('MTN');
  const [amount, setAmount] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!profile) return null;

  const depositNumber = provider === 'MTN' ? DEPOSIT_NUMBERS.MTN : DEPOSIT_NUMBERS.Airtel;

  async function handleConfirmPin() {
    setError('');
    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN.');
      return;
    }
    if (pin !== profile!.pin) {
      setError('Incorrect PIN. Please try again.');
      return;
    }

    setLoading(true);
    const ref = `DEP${Date.now().toString().slice(-8)}`;

    const { error: txError } = await supabase.from('transactions').insert({
      user_id: profile!.id,
      type: 'deposit',
      amount: Number(amount),
      status: 'completed',
      provider,
      phone: phone || profile!.phone,
      description: `Deposit via ${provider} to ${depositNumber}`,
      reference: ref,
    });

    if (txError) {
      setError('Failed to record deposit. Please try again.');
      setLoading(false);
      return;
    }

    await supabase
      .from('profiles')
      .update({
        balance: profile!.balance + Number(amount),
        total_deposited: profile!.total_deposited + Number(amount),
      })
      .eq('id', profile!.id);

    await refreshProfile();
    setLoading(false);
    setStep('success');
  }

  function reset() {
    setStep('details');
    setAmount('');
    setPhone('');
    setPin('');
    setError('');
  }

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center">
          <ArrowDownCircle className="w-5 h-5 text-emerald-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-800">Deposit Money</h1>
          <p className="text-sm text-gray-500">Current balance: {formatUGX(profile.balance)}</p>
        </div>
      </div>

      {step === 'details' && (
        <div className="space-y-5">
          {/* Provider Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Provider</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setProvider('MTN')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                  provider === 'MTN'
                    ? 'border-yellow-400 bg-yellow-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <Smartphone className="w-7 h-7 text-yellow-500" />
                <span className="font-semibold text-sm">MTN MoMo</span>
              </button>
              <button
                onClick={() => setProvider('Airtel')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                  provider === 'Airtel'
                    ? 'border-red-400 bg-red-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <Smartphone className="w-7 h-7 text-red-500" />
                <span className="font-semibold text-sm">Airtel Money</span>
              </button>
            </div>
          </div>

          {/* Deposit Number Display */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4">
            <p className="text-xs text-blue-600 font-medium mb-1">Send money to this {provider} number:</p>
            <p className="text-2xl font-bold text-blue-800 tracking-wide">{depositNumber}</p>
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Amount (UGX)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 50000"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all"
            />
          </div>

          {/* Phone (optional) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              Your {provider} Phone Number <span className="text-gray-400">(optional)</span>
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder={profile.phone}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <button
            onClick={() => {
              if (!amount || Number(amount) < 1000) {
                setError('Minimum deposit is UGX 1,000.');
                return;
              }
              setError('');
              setStep('pin');
            }}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-200"
          >
            Continue to Confirm
          </button>
        </div>
      )}

      {step === 'pin' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="w-5 h-5 text-emerald-600" />
              <h2 className="font-semibold text-gray-800">Enter PIN to Confirm</h2>
            </div>
            <div className="space-y-2 mb-5 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Provider</span><span className="font-medium">{provider}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Deposit to</span><span className="font-medium">{depositNumber}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Amount</span><span className="font-bold text-emerald-600">{formatUGX(Number(amount))}</span></div>
            </div>
            <p className="text-center text-sm text-gray-500 mb-4">Enter your 4-digit PIN</p>
            <PinInput value={pin} onChange={setPin} />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => { setStep('details'); setPin(''); setError(''); }}
              className="flex-1 py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-all"
            >
              Back
            </button>
            <button
              onClick={handleConfirmPin}
              disabled={loading}
              className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-200"
            >
              {loading ? 'Processing...' : 'Confirm Deposit'}
            </button>
          </div>
        </div>
      )}

      {step === 'success' && (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-12 h-12 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Deposit Successful!</h2>
          <p className="text-gray-500 text-sm mb-1">{formatUGX(Number(amount))} via {provider}</p>
          <p className="text-gray-400 text-xs mb-6">Your balance has been updated.</p>
          <button
            onClick={reset}
            className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-all"
          >
            Make Another Deposit
          </button>
        </div>
      )}
    </div>
  );
}
