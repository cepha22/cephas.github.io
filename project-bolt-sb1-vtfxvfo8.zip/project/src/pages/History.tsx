import { useEffect, useState } from 'react';
import { ArrowDownCircle, ArrowUpCircle, TrendingUp, Coins, Clock } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatUGX, formatDate } from '@/lib/constants';
import type { Transaction } from '@/lib/types';

const typeConfig = {
  deposit: { icon: ArrowDownCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Deposit' },
  withdrawal: { icon: ArrowUpCircle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Withdrawal' },
  investment: { icon: TrendingUp, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Investment' },
  profit: { icon: Coins, color: 'text-purple-600', bg: 'bg-purple-50', label: 'Profit' },
};

const statusColors: Record<string, string> = {
  completed: 'bg-emerald-100 text-emerald-700',
  pending: 'bg-amber-100 text-amber-700',
  failed: 'bg-red-100 text-red-700',
};

export default function History() {
  const { profile } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filter, setFilter] = useState<'all' | 'deposit' | 'withdrawal' | 'investment' | 'profit'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false });
      if (data) setTransactions(data as Transaction[]);
      setLoading(false);
    })();
  }, [profile?.id]);

  if (!profile) return null;

  const filtered = filter === 'all' ? transactions : transactions.filter((t) => t.type === filter);

  const filters: { key: typeof filter; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'deposit', label: 'Deposits' },
    { key: 'withdrawal', label: 'Withdrawals' },
    { key: 'investment', label: 'Investments' },
    { key: 'profit', label: 'Profits' },
  ];

  return (
    <div className="p-5 space-y-4">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
          <Clock className="w-5 h-5 text-gray-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-800">Transaction History</h1>
          <p className="text-sm text-gray-500">{transactions.length} transactions</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              filter === f.key
                ? 'bg-emerald-600 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Transaction List */}
      {loading ? (
        <div className="text-center py-12 text-gray-400 text-sm">Loading transactions...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-gray-100">
          <Clock className="w-10 h-10 text-gray-300 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No transactions yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((tx) => {
            const config = typeConfig[tx.type];
            const Icon = config.icon;
            const isPositive = tx.type === 'deposit' || tx.type === 'profit';
            return (
              <div key={tx.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex items-center gap-3">
                <div className={`w-10 h-10 ${config.bg} rounded-xl flex items-center justify-center shrink-0`}>
                  <Icon className={`w-5 h-5 ${config.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm text-gray-800">{config.label}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[tx.status]}`}>
                      {tx.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 truncate">
                    {tx.description || config.label} · {formatDate(tx.created_at)}
                  </p>
                  {tx.provider && (
                    <p className="text-xs text-gray-400">{tx.provider}{tx.phone ? ` · ${tx.phone}` : ''}</p>
                  )}
                </div>
                <div className="text-right shrink-0">
                  <p className={`font-bold text-sm ${isPositive ? 'text-emerald-600' : 'text-gray-700'}`}>
                    {isPositive ? '+' : '-'}{formatUGX(tx.amount)}
                  </p>
                  {tx.reference && <p className="text-[10px] text-gray-400">{tx.reference}</p>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
