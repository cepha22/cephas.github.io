import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, CheckCircle, AlertCircle, Lock, ArrowRight } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatUGX } from '@/lib/constants';
import PinInput from '@/components/PinInput';
import type { InvestmentPackage } from '@/lib/types';

const packageColors: Record<string, string> = {
  Starter: 'from-gray-400 to-gray-600',
  Bronze: 'from-amber-500 to-amber-700',
  Silver: 'from-slate-400 to-slate-600',
  Gold: 'from-yellow-400 to-yellow-600',
  Platinum: 'from-cyan-400 to-cyan-600',
  Diamond: 'from-blue-400 to-blue-600',
  Elite: 'from-purple-400 to-purple-600',
  VIP: 'from-emerald-400 to-emerald-600',
};

const packageIcons: Record<string, string> = {
  Starter: '🌱',
  Bronze: '🥉',
  Silver: '🥈',
  Gold: '🥇',
  Platinum: '💎',
  Diamond: '💠',
  Elite: '👑',
  VIP: '⭐',
};

type Step = 'browse' | 'details' | 'pin' | 'success';

export default function Invest() {
  const { profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [packages, setPackages] = useState<InvestmentPackage[]>([]);
  const [step, setStep] = useState<Step>('browse');
  const [selectedPkg, setSelectedPkg] = useState<InvestmentPackage | null>(null);
  const [amount, setAmount] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('investment_packages')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      if (data) setPackages(data as InvestmentPackage[]);
    })();
  }, []);

  if (!profile) return null;

  async function handleConfirmPin() {
    setError('');
    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN.');
      return;
    }
    if (pin !== profile!.pin) {
      setError('Incorrect PIN.');
      return;
    }

    const amt = Number(amount);
    if (amt > profile!.balance) {
      setError('Insufficient balance. Please deposit first.');
      return;
    }

    setLoading(true);
    const pkg = selectedPkg!;
    const dailyProfit = amt * pkg.daily_rate;
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + pkg.duration_days);

    const { error: invError } = await supabase.from('investments').insert({
      user_id: profile!.id,
      package_id: pkg.id,
      amount: amt,
      daily_profit: dailyProfit,
      end_date: endDate.toISOString(),
      status: 'active',
    });

    if (invError) {
      setError('Failed to create investment. Please try again.');
      setLoading(false);
      return;
    }

    await supabase.from('transactions').insert({
      user_id: profile!.id,
      type: 'investment',
      amount: amt,
      status: 'completed',
      description: `Investment in ${pkg.name} package`,
    });

    await supabase
      .from('profiles')
      .update({ balance: profile!.balance - amt })
      .eq('id', profile!.id);

    await refreshProfile();
    setLoading(false);
    setStep('success');
  }

  function reset() {
    setStep('browse');
    setSelectedPkg(null);
    setAmount('');
    setPin('');
    setError('');
  }

  // ===== BROWSE STEP =====
  if (step === 'browse') {
    return (
      <div className="p-5 space-y-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">Investment Packages</h1>
            <p className="text-sm text-gray-500">Balance: {formatUGX(profile.balance)}</p>
          </div>
        </div>

        {profile.balance < 10000 && (
          <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
            <p className="text-sm text-amber-700">
              Your balance is low. Deposit at least UGX 10,000 to start investing.
            </p>
          </div>
        )}

        <div className="space-y-3">
          {packages.map((pkg) => {
            const gradient = packageColors[pkg.name] ?? 'from-emerald-400 to-emerald-600';
            const icon = packageIcons[pkg.name] ?? '📊';
            return (
              <button
                key={pkg.id}
                onClick={() => {
                  setSelectedPkg(pkg);
                  setAmount(pkg.min_amount.toString());
                  setStep('details');
                }}
                className="w-full bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left"
              >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-2xl`}>
                          {icon}
                        </div>
                        <div>
                          <p className="font-bold text-gray-800">{pkg.name}</p>
                          <p className="text-xs text-gray-400">{pkg.daily_rate * 100}% daily for {pkg.duration_days} days</p>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-gray-300" />
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Min: {formatUGX(pkg.min_amount)}</span>
                      <span>Max: {formatUGX(pkg.max_amount)}</span>
                    </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // ===== DETAILS STEP =====
  if (step === 'details' && selectedPkg) {
    const amt = Number(amount) || 0;
    const dailyProfit = amt * selectedPkg.daily_rate;
    const totalProfit = dailyProfit * selectedPkg.duration_days;
    const totalReturn = amt + totalProfit;

    return (
      <div className="p-5 space-y-5">
        <button onClick={reset} className="text-sm text-gray-500 hover:text-gray-700">
          ← Back to packages
        </button>

        <div className={`bg-gradient-to-br ${packageColors[selectedPkg.name]} rounded-3xl p-6 text-white shadow-xl`}>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-3xl">{packageIcons[selectedPkg.name]}</span>
            <div>
              <h2 className="text-2xl font-bold">{selectedPkg.name}</h2>
              <p className="text-white/80 text-sm">{selectedPkg.daily_rate * 100}% daily for {selectedPkg.duration_days} days</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/20">
            <div>
              <p className="text-white/70 text-xs">Min Investment</p>
              <p className="font-semibold">{formatUGX(selectedPkg.min_amount)}</p>
            </div>
            <div>
              <p className="text-white/70 text-xs">Max Investment</p>
              <p className="font-semibold">{formatUGX(selectedPkg.max_amount)}</p>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Investment Amount (UGX)</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`Min ${formatUGX(selectedPkg.min_amount)}`}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all"
          />
          {amt > 0 && (
            <div className="mt-4 bg-gray-50 rounded-2xl p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Daily Profit</span><span className="font-medium text-emerald-600">{formatUGX(dailyProfit)}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Total Profit ({selectedPkg.duration_days} days)</span><span className="font-medium text-emerald-600">{formatUGX(totalProfit)}</span></div>
              <div className="flex justify-between pt-2 border-t border-gray-200"><span className="text-gray-700 font-medium">Total Return</span><span className="font-bold text-gray-800">{formatUGX(totalReturn)}</span></div>
            </div>
          )}
        </div>

        {error && (
          <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <button
          onClick={() => {
            const amt = Number(amount);
            if (!amt || amt < selectedPkg.min_amount) {
              setError(`Minimum investment is ${formatUGX(selectedPkg.min_amount)}.`);
              return;
            }
            if (amt > selectedPkg.max_amount) {
              setError(`Maximum investment is ${formatUGX(selectedPkg.max_amount)}.`);
              return;
            }
            if (amt > profile.balance) {
              setError('Insufficient balance. Please deposit first.');
              return;
            }
            setError('');
            setStep('pin');
          }}
          className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-200"
        >
          Continue to Confirm
        </button>
      </div>
    );
  }

  // ===== PIN STEP =====
  if (step === 'pin') {
    return (
      <div className="p-5 space-y-6">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-5 h-5 text-emerald-600" />
            <h2 className="font-semibold text-gray-800">Enter PIN to Confirm Investment</h2>
          </div>
          <div className="space-y-2 mb-5 text-sm">
            <div className="flex justify-between"><span className="text-gray-500">Package</span><span className="font-medium">{selectedPkg?.name}</span></div>
            <div className="flex justify-between"><span className="text-gray-500">Amount</span><span className="font-bold text-emerald-600">{formatUGX(Number(amount))}</span></div>
            <div className="flex justify-between"><span className="text-gray-500">Daily Profit</span><span className="font-medium">{formatUGX(Number(amount) * (selectedPkg?.daily_rate ?? 0))}</span></div>
          </div>
          <p className="text-center text-sm text-gray-500 mb-4">Enter your 4-digit PIN</p>
          <PinInput value={pin} onChange={setPin} />
        </div>

        {error && (
          <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={() => { setStep('details'); setPin(''); setError(''); }}
            className="flex-1 py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-all"
          >
            Back
          </button>
          <button
            onClick={handleConfirmPin}
            disabled={loading}
            className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-200"
          >
            {loading ? 'Processing...' : 'Confirm Investment'}
          </button>
        </div>
      </div>
    );
  }

  // ===== SUCCESS STEP =====
  return (
    <div className="flex flex-col items-center justify-center py-16 p-5">
      <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-4">
        <CheckCircle className="w-12 h-12 text-emerald-600" />
      </div>
      <h2 className="text-xl font-bold text-gray-800 mb-2">Investment Active!</h2>
      <p className="text-gray-500 text-sm mb-1">{formatUGX(Number(amount))} in {selectedPkg?.name}</p>
      <p className="text-gray-400 text-xs mb-6">Your investment is now earning daily profit.</p>
      <div className="flex gap-3">
        <button
          onClick={reset}
          className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-all"
        >
          Invest Again
        </button>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-all"
        >
          Go Home
        </button>
      </div>
    </div>
  );
}
