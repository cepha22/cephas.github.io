import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User as UserIcon, Phone, Lock, TrendingUp, Award, ArrowDownCircle, ArrowUpCircle, LogOut, CheckCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { formatUGX, formatDate } from '@/lib/constants';

export default function Profile() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [editingPin, setEditingPin] = useState(false);
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  if (!profile) return null;

  async function handleChangePin() {
    setError('');
    setSuccess('');

    if (oldPin !== profile!.pin) {
      setError('Old PIN is incorrect.');
      return;
    }
    if (newPin.length !== 4) {
      setError('New PIN must be 4 digits.');
      return;
    }
    if (newPin !== confirmPin) {
      setError('PINs do not match.');
      return;
    }

    setLoading(true);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ pin: newPin })
      .eq('id', profile!.id);

    setLoading(false);

    if (updateError) {
      setError('Failed to update PIN. Please try again.');
      return;
    }

    setSuccess('PIN updated successfully!');
    setEditingPin(false);
    setOldPin('');
    setNewPin('');
    setConfirmPin('');
  }

  const stats = [
    { icon: ArrowDownCircle, label: 'Total Deposited', value: formatUGX(profile.total_deposited), color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { icon: ArrowUpCircle, label: 'Total Withdrawn', value: formatUGX(profile.total_withdrawn), color: 'text-amber-600', bg: 'bg-amber-50' },
    { icon: TrendingUp, label: 'Investment Balance', value: formatUGX(profile.balance), color: 'text-blue-600', bg: 'bg-blue-50' },
    { icon: Award, label: 'Profit Balance', value: formatUGX(profile.profit_balance), color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  return (
    <div className="p-5 space-y-5">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
            <UserIcon className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{profile.full_name}</h1>
            <p className="text-emerald-100 text-sm flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" />
              {profile.phone}
            </p>
            <p className="text-emerald-200 text-xs mt-1">Member since {formatDate(profile.created_at)}</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
              <div className={`w-9 h-9 ${s.bg} rounded-lg flex items-center justify-center mb-2`}>
                <Icon className={`w-4.5 h-4.5 ${s.color}`} />
              </div>
              <p className="text-xs text-gray-500 mb-0.5">{s.label}</p>
              <p className={`text-base font-bold ${s.color}`}>{s.value}</p>
            </div>
          );
        })}
      </div>

      {/* PIN Management */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <Lock className="w-5 h-5 text-gray-600" />
          <h2 className="font-semibold text-gray-800">PIN Settings</h2>
        </div>

        {success && (
          <div className="mb-4 flex items-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-3 rounded-xl text-sm">
            <CheckCircle className="w-4 h-4 shrink-0" />
            {success}
          </div>
        )}

        {!editingPin ? (
          <button
            onClick={() => setEditingPin(true)}
            className="w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-xl transition-all text-sm"
          >
            Change PIN
          </button>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Old PIN</label>
              <input
                type="tel"
                inputMode="numeric"
                maxLength={4}
                value={oldPin}
                onChange={(e) => setOldPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all tracking-[0.3em] font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">New PIN</label>
              <input
                type="tel"
                inputMode="numeric"
                maxLength={4}
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all tracking-[0.3em] font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Confirm New PIN</label>
              <input
                type="tel"
                inputMode="numeric"
                maxLength={4}
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none transition-all tracking-[0.3em] font-bold"
              />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div className="flex gap-2">
              <button
                onClick={() => { setEditingPin(false); setOldPin(''); setNewPin(''); setConfirmPin(''); setError(''); }}
                className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-xl text-sm transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleChangePin}
                disabled={loading}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-medium rounded-xl text-sm transition-all"
              >
                {loading ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Sign Out */}
      <button
        onClick={async () => {
          await signOut();
          navigate('/login');
        }}
        className="w-full py-3.5 bg-red-50 hover:bg-red-100 text-red-600 font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
      >
        <LogOut className="w-5 h-5" />
        Sign Out
      </button>

      <p className="text-center text-xs text-gray-400 pt-2">Kagoda Invest v1.0</p>
    </div>
  );
}
