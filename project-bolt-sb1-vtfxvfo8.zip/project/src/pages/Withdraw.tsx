import { useState } from 'react';
import { ArrowUpCircle, CheckCircle, AlertCircle, Lock, Smartphone, Info } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { MIN_WITHDRAWAL, formatUGX } from '@/lib/constants';
import PinInput from '@/components/PinInput';

type Step = 'details' | 'pin' | 'success';

export default function Withdraw() {
  const { profile, refreshProfile } = useAuth();
  const [step, setStep] = useState<Step>('details');
  const [provider, setProvider] = useState<'MTN' | 'Airtel'>('MTN');
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!profile) return null;

  async function handleConfirmPin() {
    setError('');
    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN.');
      return;
    }
    if (pin !== profile!.pin) {
      setError('Incorrect PIN.');
      return;
    }

    const amt = Number(amount);
    if (amt > profile!.profit_balance) {
      setError('Insufficient profit balance.');
      return;
    }

    setLoading(true);
    const ref = `WD${Date.now().toString().slice(-8)}`;

    const { error: txError } = await supabase.from('transactions').insert({
      user_id: profile!.id,
      type: 'withdrawal',
      amount: amt,
      status: 'completed',
      provider,
      phone: phone || profile!.phone,
      description: `Profit withdrawal via ${provider}`,
      reference: ref,
    });

    if (txError) {
      setError('Failed to process withdrawal. Please try again.');
      setLoading(false);
      return;
    }

    await supabase
      .from('profiles')
      .update({
        profit_balance: profile!.profit_balance - amt,
        total_withdrawn: profile!.total_withdrawn + amt,
      })
      .eq('id', profile!.id);

    await refreshProfile();
    setLoading(false);
    setStep('success');
  }

  function reset() {
    setStep('details');
    setAmount('');
    setPhone('');
    setPin('');
    setError('');
  }

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center">
          <ArrowUpCircle className="w-5 h-5 text-amber-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-800">Withdraw Profits</h1>
          <p className="text-sm text-gray-500">Available: {formatUGX(profile.profit_balance)}</p>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
        <div className="text-sm text-blue-700">
          <p className="font-medium mb-1">Profit-only withdrawals</p>
          <p className="text-blue-600 text-xs">You can only withdraw profits. Minimum withdrawal is {formatUGX(MIN_WITHDRAWAL)}.</p>
        </div>
      </div>

      {step === 'details' && (
        <div className="space-y-5">
          {/* Provider */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Provider</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setProvider('MTN')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                  provider === 'MTN' ? 'border-yellow-400 bg-yellow-50' : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <Smartphone className="w-7 h-7 text-yellow-500" />
                <span className="font-semibold text-sm">MTN MoMo</span>
              </button>
              <button
                onClick={() => setProvider('Airtel')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                  provider === 'Airtel' ? 'border-red-400 bg-red-50' : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <Smartphone className="w-7 h-7 text-red-500" />
                <span className="font-semibold text-sm">Airtel Money</span>
              </button>
            </div>
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Amount (UGX)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={`Min ${formatUGX(MIN_WITHDRAWAL)}`}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition-all"
            />
            <button
              onClick={() => setAmount(profile.profit_balance.toString())}
              className="text-xs text-amber-600 font-medium mt-1 hover:text-amber-700"
            >
              Withdraw all ({formatUGX(profile.profit_balance)})
            </button>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              {provider} Phone Number <span className="text-gray-400">(optional)</span>
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder={profile.phone}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition-all"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <button
            onClick={() => {
              const amt = Number(amount);
              if (!amt || amt < MIN_WITHDRAWAL) {
                setError(`Minimum withdrawal is ${formatUGX(MIN_WITHDRAWAL)}.`);
                return;
              }
              if (amt > profile.profit_balance) {
                setError('Insufficient profit balance.');
                return;
              }
              setError('');
              setStep('pin');
            }}
            className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-xl transition-all shadow-lg shadow-amber-200"
          >
            Continue to Confirm
          </button>
        </div>
      )}

      {step === 'pin' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="w-5 h-5 text-amber-600" />
              <h2 className="font-semibold text-gray-800">Enter PIN to Confirm Withdrawal</h2>
            </div>
            <div className="space-y-2 mb-5 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Provider</span><span className="font-medium">{provider}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">To Phone</span><span className="font-medium">{phone || profile.phone}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Amount</span><span className="font-bold text-amber-600">{formatUGX(Number(amount))}</span></div>
            </div>
            <p className="text-center text-sm text-gray-500 mb-4">Enter your 4-digit PIN</p>
            <PinInput value={pin} onChange={setPin} />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => { setStep('details'); setPin(''); setError(''); }}
              className="flex-1 py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-all"
            >
              Back
            </button>
            <button
              onClick={handleConfirmPin}
              disabled={loading}
              className="flex-1 py-3.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-all shadow-lg shadow-amber-200"
            >
              {loading ? 'Processing...' : 'Confirm Withdrawal'}
            </button>
          </div>
        </div>
      )}

      {step === 'success' && (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-12 h-12 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Withdrawal Successful!</h2>
          <p className="text-gray-500 text-sm mb-1">{formatUGX(Number(amount))} via {provider}</p>
          <p className="text-gray-400 text-xs mb-6">Funds will be sent to {phone || profile.phone}.</p>
          <button
            onClick={reset}
            className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-xl transition-all"
          >
            Done
          </button>
        </div>
      )}
    </div>
  );
}
