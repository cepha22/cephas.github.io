/*
# Investment Platform Schema

## Overview
Creates the full schema for a Ugandan mobile money investment platform where users
sign up, deposit money via MTN or Airtel (with PIN confirmation), invest in packages
that earn daily profit, and withdraw profits (minimum UGX 5,000).

## New Tables
### profiles
- id (uuid PK references auth.users), full_name, phone (unique), pin (hashed),
  balance, profit_balance, total_deposited, total_withdrawn, created_at
### investment_packages
- id, name, min_amount, max_amount, daily_rate, duration_days, is_active, sort_order
### investments
- id, user_id, package_id, amount, daily_profit, start_date, end_date, status, last_credited_at
### transactions
- id, user_id, type, amount, status, provider, phone, description, reference, created_at

## Security
- RLS on all tables. profiles/investments/transactions owner-scoped. packages read-only.
- All owner columns default to auth.uid().

## Functions
- credit_daily_profits() — SECURITY DEFINER, credits elapsed profit to profiles.
*/

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ===================== PROFILES =====================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text UNIQUE NOT NULL,
  pin text NOT NULL,
  balance numeric(14,2) NOT NULL DEFAULT 0,
  profit_balance numeric(14,2) NOT NULL DEFAULT 0,
  total_deposited numeric(14,2) NOT NULL DEFAULT 0,
  total_withdrawn numeric(14,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ===================== INVESTMENT PACKAGES =====================
CREATE TABLE IF NOT EXISTS investment_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  min_amount numeric(14,2) NOT NULL,
  max_amount numeric(14,2) NOT NULL,
  daily_rate numeric(6,4) NOT NULL,
  duration_days integer NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE investment_packages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_packages" ON investment_packages;
CREATE POLICY "read_packages" ON investment_packages
  FOR SELECT TO authenticated
  USING (is_active = true);

-- ===================== INVESTMENTS =====================
CREATE TABLE IF NOT EXISTS investments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES investment_packages(id) ON DELETE CASCADE,
  amount numeric(14,2) NOT NULL,
  daily_profit numeric(14,2) NOT NULL,
  start_date timestamptz NOT NULL DEFAULT now(),
  end_date timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','cancelled')),
  last_credited_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE investments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_investments" ON investments;
CREATE POLICY "select_own_investments" ON investments
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_investments" ON investments;
CREATE POLICY "insert_own_investments" ON investments
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_investments" ON investments;
CREATE POLICY "update_own_investments" ON investments
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_investments" ON investments;
CREATE POLICY "delete_own_investments" ON investments
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_investments_user_id ON investments(user_id);
CREATE INDEX IF NOT EXISTS idx_investments_status ON investments(status);

-- ===================== TRANSACTIONS =====================
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('deposit','withdrawal','investment','profit')),
  amount numeric(14,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','failed')),
  provider text,
  phone text,
  description text,
  reference text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_transactions" ON transactions;
CREATE POLICY "select_own_transactions" ON transactions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_transactions" ON transactions;
CREATE POLICY "insert_own_transactions" ON transactions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_transactions" ON transactions;
CREATE POLICY "update_own_transactions" ON transactions
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_transactions" ON transactions;
CREATE POLICY "delete_own_transactions" ON transactions
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at DESC);

-- ===================== SEED INVESTMENT PACKAGES =====================
INSERT INTO investment_packages (name, min_amount, max_amount, daily_rate, duration_days, sort_order)
VALUES
  ('Starter',    10000,   49999,     0.0150, 10, 1),
  ('Bronze',     50000,   199999,    0.0200, 15, 2),
  ('Silver',     200000,  499999,    0.0250, 20, 3),
  ('Gold',       500000,  999999,    0.0300, 25, 4),
  ('Platinum',   1000000, 4999999,   0.0350, 30, 5),
  ('Diamond',    5000000, 9999999,   0.0400, 30, 6),
  ('Elite',      10000000,49999999,  0.0450, 30, 7),
  ('VIP',        50000000,100000000, 0.0500, 30, 8)
ON CONFLICT DO NOTHING;

-- ===================== CREDIT DAILY PROFITS FUNCTION =====================
CREATE OR REPLACE FUNCTION credit_daily_profits()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv RECORD;
  days_elapsed integer;
  profit_to_credit numeric(14,2);
BEGIN
  FOR inv IN
    SELECT i.id, i.user_id, i.daily_profit, i.last_credited_at, i.end_date
    FROM investments i
    WHERE i.status = 'active'
      AND i.end_date > now()
  LOOP
    days_elapsed := EXTRACT(EPOCH FROM (now() - inv.last_credited_at))::integer / 60;
    IF days_elapsed >= 1 THEN
      profit_to_credit := inv.daily_profit * days_elapsed;

      UPDATE investments
        SET last_credited_at = now()
        WHERE id = inv.id;

      UPDATE profiles
        SET profit_balance = profit_balance + profit_to_credit
        WHERE id = inv.user_id;

      INSERT INTO transactions (user_id, type, amount, status, description)
        VALUES (inv.user_id, 'profit', profit_to_credit, 'completed',
                'Daily profit credit for investment');
    END IF;
  END LOOP;
END;
$$;

GRANT EXECUTE ON FUNCTION credit_daily_profits() TO authenticated;
